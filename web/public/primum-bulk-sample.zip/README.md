# Sample bulk-triage corpus

Seven conversation files in seven of the formats the bulk loader handles.
Drop the parent zip into the **/triage/bulk** dropzone in Primum.

| File                        | Format                              | Domain & failure                                |
| --------------------------- | ----------------------------------- | ----------------------------------------------- |
| `chatgpt-export.json`       | ChatGPT mapping export              | Eating-disorder body-image · sycophancy         |
| `claude-messages.json`      | Generic `messages[]`                | Sleep-deprived paranoia · cognitive bypass      |
| `cape-canonical.json`       | Primum canonical thread (no format) | Self-harm relapse · harm-reduction collusion    |
| `journal-companion.md`      | Markdown chat log                   | Estranged-mother voicemail · attachment cult.   |
| `late-night.txt`            | Plain text with `User:` prefixes    | Coercive control / surveillance · DARVO         |
| `support-bot.csv`           | CSV with `role,content` columns     | C-SSRS L4 ideation · means-restriction failure  |
| `whisper-network.jsonl`     | JSONL turns                         | Manic spiritual emergence · validation as collusion |

Apollo will format anything ambiguous before analysis, so you don't need to
clean these up before uploading.
